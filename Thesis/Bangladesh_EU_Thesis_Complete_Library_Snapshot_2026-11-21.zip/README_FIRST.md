# Bangladesh-EU MITB Thesis: complete saved Library snapshot

Snapshot date: 21 November 2026

This bundle contains all 67 original files present at the time of retrieval in ChatGPT Library folder:
/Thesis Research/Bangladesh EU Market Access Validation/Integrated Research Pack

Contains original research notes, raw original Codex CSV, audit registers, scripts, spreadsheets, research draft, and intermediate ZIP packages. No files were edited. SHA256 digests are in SHA256_MANIFEST.csv, enabling later validation.

Existing GitHub repository: https://github.com/mafijulrigan39-boop/thesis
GitHub archival update: https://github.com/mafijulrigan39-boop/thesis/commit/d819496c1808bac47bd0196987e3ea956553b555
Library text-copy folder: https://github.com/mafijulrigan39-boop/thesis/tree/main/research_archive/library_snapshot_2026-11-21

NOTE: This ZIP holds the 67 original *Library* files. The extensive official data and code already on GitHub, including task C/D/E/F raw responses and executed analyses, are referenced by the Library files but are not separately duplicated into this ZIP. CSVs in the GitHub new parsed_csv folder are parser exports, not byte-identical to the originals retained HERE.

Research integrity: 2025 cross-sectional and 2026 dated-source tariff analyses have been executed. 2012-2025 harmonized CN8 code-level growth and legally payable prospective 2027 post-EBA duties remain uncertified; see the latest Task F empirical report.
