#!/usr/bin/env python3
"""Produce a STRICT 14-year observed-vs-unobserved panel from original uploaded trade CSV.

NO official code-year validity is inferred. Missing != 0. The union of observed
codes is *not* assumed valid in every year. Only observed zeros are true zeroes.
"""
import argparse, csv, hashlib, json
from pathlib import Path
from collections import Counter


def make(input_file:Path,out:Path):
    out.mkdir(parents=True,exist_ok=True)
    d={};codes=set();values=0; zeros=0
    with input_file.open(newline='',encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            year=int(row['TIME_PERIOD']);code=row['PRODUCT'];val=int(row['OBS_VALUE'])
            if not 2012<=year<=2025 or len(code)!=8 or not code.isdigit() or val<0: raise ValueError('Invalid input row')
            key=(year,code)
            if key in d:raise AssertionError('duplicate '+str(key))
            if row['PARTNER']!='BD' or row['REPORTER']!='EU27_2020' or row['DATASET']!='DS-059322':raise AssertionError('Unexpected series')
            d[key]=val;codes.add(code);values+=val;zeros+=int(val==0)
    path=out/'DS059322_observed_vs_absent_CODE_VALIDITY_UNKNOWN.csv'
    year_counts=Counter()
    with path.open('w',newline='',encoding='utf-8') as f:
        wr=csv.writer(f);wr.writerow(['YEAR','PRODUCT','HS2','RECORD_STATUS','STRICT_OBS_VALUE_EUR','EXPLICIT_ZERO_FLAG','OFFICIAL_CODE_VALIDITY'])
        for code in sorted(codes):
            for year in range(2012,2026):
                v=d.get((year,code));is_observed=(year,code) in d
                status=('OBSERVED_ZERO' if v==0 else 'OBSERVED_POSITIVE') if is_observed else 'NO_REPORTED_OBSERVATION_VALIDITY_UNKNOWN'
                wr.writerow([year,code,code[:2],status,v if is_observed else '',int(is_observed and v==0),'NOT_VERIFIED'])
                year_counts[status]+=1
    manifest={'source_file':str(input_file),'source_sha256':hashlib.sha256(input_file.read_bytes()).hexdigest(),
              'years':'2012-2025','distinct_codes_observed_in_any_year':len(codes),
              'actual_observation_rows':len(d),'explicit_observed_zeros':zeros,
              'observed_value_eur':values,'status_counts':dict(year_counts),
              'interpretation':'Unreported row does not prove code valid or prove zero trade. This product-union panel is not an official CN validity file.'}
    (out/'DS059322_missingness_grid_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return manifest

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input',required=True,type=Path);p.add_argument('--out',required=True,type=Path)
    x=p.parse_args();print(json.dumps(make(x.input,x.out),indent=2))
