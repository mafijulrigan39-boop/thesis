#!/usr/bin/env python3
"""Task B: Audit UNHARMONIZED source observations, without fabricating CN correspondences.
Only 2025 native CN8 rankings and HS2 descriptive summaries are produced. Historical
product-level growth requires the separate official strict harmonizer.
"""
import csv, json, hashlib, argparse, re
from collections import defaultdict
from pathlib import Path
from datetime import datetime, timezone

YEAR_FIRST, YEAR_LAST = 2012, 2025
# Historical-change flags from the publicly accessible cran/harmonizer Eurostat RAMON-
# derived CN8 concordance (GitHub blob SHA 1933b8d69051ffb7a9f1f30afdc0a4976696f219).
# This is SECONDARY EVIDENCE covering 2012-2022, not an official 2012-2025 mapping.
HISTORICAL_CHANGE_FLAGS = {
    '62024010':'2021-2022','62014010':'2021-2022','03061792':'2016-2017',
    '62103000':'2021-2022','62102000':'2021-2022','62014090':'2021-2022',
    '62023010':'2021-2022','62105000':'2021-2022','62104000':'2021-2022',
    '62024090':'2021-2022','62013010':'2021-2022','62013090':'2021-2022',
    '62019000':'2021-2022','63079098':'2020-2021','03061799':'2016-2017',
    '62023090':'2021-2022','95030095':'2016-2017',
    '39269097':'2016-2017|2019-2020|2020-2021',
    '62029000':'2021-2022','61161020':'2021-2022'
}
CRAN_URL='https://github.com/cran/harmonizer/blob/master/inst/extdata/CN8/CN8_concordances_1988_2022.csv'

def write_csv(path,fields,rows):
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); w.writeheader();w.writerows(rows)

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    dest=Path(a.out);dest.mkdir(parents=True,exist_ok=True)
    values={y:{} for y in range(YEAR_FIRST,YEAR_LAST+1)}
    with open(a.input,encoding='utf-8-sig',newline='') as f:
        rdr=csv.DictReader(f)
        expected=['DATASET','FREQ','REPORTER','PARTNER','PRODUCT','FLOW','STAT_PROCEDURE','INDICATORS','TIME_PERIOD','OBS_VALUE']
        assert rdr.fieldnames==expected,rdr.fieldnames
        for r in rdr:
            assert (r['DATASET'],r['FREQ'],r['REPORTER'],r['PARTNER'],r['FLOW'],r['STAT_PROCEDURE'],r['INDICATORS'])==('DS-059322','A','EU27_2020','BD','1','T','VALUE_IN_EUR')
            code=r['PRODUCT']; year=int(r['TIME_PERIOD']);v=int(r['OBS_VALUE'])
            assert re.fullmatch(r'[0-9]{8}',code) and YEAR_FIRST<=year<=YEAR_LAST and v>=0
            assert code not in values[year], (year,code)
            values[year][code]=v
    observed=set().union(*(set(x) for x in values.values()))
    full_year=set.intersection(*(set(x) for x in values.values()))
    assert len(observed)==4953 and len(full_year)==690
    total_2025=sum(values[2025].values())
    latest_sorted=sorted(values[2025].items(),key=lambda x:(-x[1],x[0]))
    top=latest_sorted[:200]
    trows=[]
    for rank,(code,v) in enumerate(top,1):
        trows.append(dict(rank=rank,cn8_2025=code,year=2025,value_eur=v,share_of_bd_cn8_2025_pct=100*v/total_2025,
           catalogue_line_2025_validated='NO',official_2025_description='',
           strict_longitudinal_comparability='NOT_VERIFIED',
           historical_change_2012_2022_secondary=HISTORICAL_CHANGE_FLAGS.get(code,''),
           historical_change_evidence_source=CRAN_URL if code in HISTORICAL_CHANGE_FLAGS else '',
           correspondence_2023_2025_checked='NO',tariff_use='NATIVE_2025_CODE_PENDING_2025_OFFICIAL_VALIDITY'))
    fields=['rank','cn8_2025','year','value_eur','share_of_bd_cn8_2025_pct','catalogue_line_2025_validated',
            'official_2025_description','strict_longitudinal_comparability','historical_change_2012_2022_secondary',
            'historical_change_evidence_source','correspondence_2023_2025_checked','tariff_use']
    write_csv(dest/'2025_top200_native_code_with_concordance_risk.csv',fields,trows)
    turn=[]
    for y in range(YEAR_FIRST,YEAR_LAST+1):
        current=set(values[y]);prev=set(values[y-1]) if y>YEAR_FIRST else set()
        previous_value=sum(values[y][c] for c in current&prev)
        turn.append(dict(year=y,observed_codes=len(current),also_observed_preceding_year=len(current&prev) if y>YEAR_FIRST else '',
               only_observed_this_year_not_previous=len(current-prev) if y>YEAR_FIRST else '',
               previously_observed_not_this_year=len(prev-current) if y>YEAR_FIRST else '',
               pct_current_value_in_codes_observed_last_year=(100*previous_value/sum(values[y].values()) if y>YEAR_FIRST else ''),
               interpretation='EMPIRICAL_PRESENCE_NOT_OFFICIAL_CODE_VALIDITY',
               trade_value_eur=sum(values[y].values())))
    write_csv(dest/'annual_native_code_presence_turnover_NOT_CLASSIFICATION_CHANGES.csv',list(turn[0]),turn)
    cr=[]
    for code in sorted(observed):
        yrs=[y for y in values if code in values[y]]
        cr.append(dict(cn8_code=code,years_observed=len(yrs),first_year_observed=min(yrs),last_year_observed=max(yrs),
          all_14_years_observed=('YES' if len(yrs)==14 else 'NO'),
          value_2025_eur=values[2025].get(code,''),
          official_cn8_semantic_stability_verified='NO',
          strict_2012_2025_growth_eligible='NO',
          missing_trade_vs_invalid_code='UNDETERMINED_WITHOUT_OFFICIAL_CATALOGUES',
          evidence='BD_COMEXT_OBSERVATIONS_ONLY'))
    write_csv(dest/'observed_code_history_UNVERIFIED_semantics.csv',list(cr[0]),cr)
    presence=[]
    for code in sorted(observed):
        row=dict(cn8_code=code)
        for y in range(YEAR_FIRST,YEAR_LAST+1):row[str(y)]='OBSERVED' if code in values[y] else ''
        row['catalogue_validity']='NOT_VERIFIED';row['cross_year_growth_allowed']='NO'
        presence.append(row)
    write_csv(dest/'presence_matrix_missing_is_not_zero.csv',list(presence[0]),presence)
    chapter_rows=[]
    for y in values:
        groups=defaultdict(int)
        for c,v in values[y].items(): groups[c[:2]]+=v
        for ch,v in sorted(groups.items()):
            chapter_rows.append(dict(year=y,hs2_chapter=ch,eu_imports_bd_eur=v,
                 definition_note='DESCRIPTIVE_BY_REPORTED_HS2_PREFIX; NOT A FULLY CONCORDED_PRODUCT_BASKET'))
    write_csv(dest/'annual_chapter_descriptive_NOT_full_concordance.csv',list(chapter_rows[0]),chapter_rows)
    req=[]
    for y in range(YEAR_FIRST,YEAR_LAST+1):
        if y>=2017:
            official='https://op.europa.eu/en/web/eu-vocabularies/eurostat'
        else:official='https://osp.stat.gov.lt/en/web/guest/kombinuotoji-nomenklatura-kn'
        req.append(dict(requirement='FULL_ANNUAL_CN_CATALOGUE',start_year=y,end_year=y,
            file_expected=f'official_inputs/CN_{y}_catalog.csv',official_source=official,
            file_locally_obtained='NO',verified_records=0,sha256='',source_retrieval='HTML_OFFICIAL_LANDING_PAGE_ONLY',
            note='Need complete CN8 codes, English description and effective-validity metadata'))
    lith='https://osp.stat.gov.lt/en/web/guest/kombinuotoji-nomenklatura-kn'
    for y in range(YEAR_FIRST,YEAR_LAST):
        if y==2024: source='https://www.dst.dk/en/Indberet/oplysningssider/intrastat/udenrigsoekonomi'
        elif 2018<=y<=2023:source=lith
        else:source=CRAN_URL
        req.append(dict(requirement='ADJACENT_YEAR_CODE_CORRESPONDENCE',start_year=y,end_year=y+1,
            file_expected=f'official_inputs/CN_{y}_to_{y+1}_changes.csv',official_source=source,
            file_locally_obtained='NO',verified_records=0,sha256='',source_retrieval='OFFICIAL_LANDING_PAGE_OR_SECONDARY_DATASET_ONLY',
            note=('CRAN harmonizer is secondary RAMON-derived: official change records required' if y<=2017 else 'Official national-statistics XLS conversion table must be imported and authenticated')))
    write_csv(dest/'official_27_source_files_register.csv',list(req[0]),req)
    manifest=dict(task='CN8 longitudinal classification concordance',date_utc=datetime.now(timezone.utc).isoformat(),
       status='PARTIAL_ONLY_OFFICIAL_FILES_NOT_DOWNLOADED',source_file=a.input,source_file_sha256=sha256(a.input),
       records=sum(map(len,values.values())),unique_codes=len(observed),complete_year_observed_codes=len(full_year),
       complete_year_candidate_2025_value_eur=sum(values[2025][c] for c in full_year),
       full_2025_value_eur=total_2025,
       top200_2025_history_flags_secondary=len(HISTORICAL_CHANGE_FLAGS),
       top200_2025_history_flags_value_eur=sum(values[2025][c] for c in HISTORICAL_CHANGE_FLAGS),
       annual_official_catalogues_retrieved=0,annual_pair_official_concordances_retrieved=0,
       official_source_lists_identified=14,official_crosswalk_joins_executed=0,
       certified_2012_2025_cn8_growth_observations=0,
       role_of_history_flags='Only traceable secondary 2012–2022 historical code-change indicators for top-200; absence does not imply stable code',
       warnings=['Observed presence is not validity or semantic stability','HS6 prefix alone does not harmonize CN8; HS changed 2017 and 2022',
                 'No official year-specific classification file downloaded in this environment','2023–2025 crosswalk not available to the analysis'],
       derived_files=[p.name for p in dest.iterdir()])
    (dest/'audit_manifest_taskB.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps({k:manifest[k] for k in ['records','unique_codes','complete_year_observed_codes','complete_year_candidate_2025_value_eur','full_2025_value_eur','top200_2025_history_flags_value_eur']},indent=2))

if __name__=='__main__':main()
