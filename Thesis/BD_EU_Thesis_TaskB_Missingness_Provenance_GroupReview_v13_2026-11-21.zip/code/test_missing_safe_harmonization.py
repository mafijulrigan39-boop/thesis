#!/usr/bin/env python3
"""Synthetic-only unit tests; never describe test fixture values as real EU trade."""
from pathlib import Path
import tempfile,csv,json,sys
sys.path.insert(0,str(Path(__file__).parent))
from create_missing_safe_harmonization import run

def write(path,cols,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)

with tempfile.TemporaryDirectory(prefix='taskb_test_') as t:
    root=Path(t);inputs=root/'inputs';inputs.mkdir()
    write(inputs/'cn8_validity_trade_panel.csv',
      ['YEAR','PRODUCT','HCN8_ID','ACTIVITY_STATUS','OBS_VALUE_EUR'],[
        {'YEAR':'2012','PRODUCT':'39269097','HCN8_ID':'G_MIX','ACTIVITY_STATUS':'OBSERVED_TRADE','OBS_VALUE_EUR':'100'},
        {'YEAR':'2012','PRODUCT':'76020019','HCN8_ID':'G_MIX','ACTIVITY_STATUS':'VERIFIED_ZERO','OBS_VALUE_EUR':'0'},
        {'YEAR':'2013','PRODUCT':'39269097','HCN8_ID':'G_MIX','ACTIVITY_STATUS':'VERIFIED_ZERO','OBS_VALUE_EUR':'0'},
        {'YEAR':'2012','PRODUCT':'61091000','HCN8_ID':'G_EXACT','ACTIVITY_STATUS':'OBSERVED_TRADE','OBS_VALUE_EUR':'0'},
        {'YEAR':'2013','PRODUCT':'61091000','HCN8_ID':'G_EXACT','ACTIVITY_STATUS':'OBSERVED_TRADE','OBS_VALUE_EUR':'200'},
        {'YEAR':'2013','PRODUCT':'76020019','HCN8_ID':'G_MIX','ACTIVITY_STATUS':'INACTIVE','OBS_VALUE_EUR':'0'},
    ])
    write(inputs/'hcn8_group_year_trade.csv',
      ['YEAR','HCN8_ID','ACTIVE_PRODUCTS','ACTIVE_MEMBER_COUNT','OBSERVED_MEMBER_COUNT','OBS_VALUE_EUR','CONTINUITY_TYPE'],[
        {'YEAR':'2012','HCN8_ID':'G_MIX','ACTIVE_PRODUCTS':'39269097|76020019','ACTIVE_MEMBER_COUNT':'2','OBSERVED_MEMBER_COUNT':'1','OBS_VALUE_EUR':'100','CONTINUITY_TYPE':'complex_MN'},
        {'YEAR':'2013','HCN8_ID':'G_MIX','ACTIVE_PRODUCTS':'39269097','ACTIVE_MEMBER_COUNT':'1','OBSERVED_MEMBER_COUNT':'0','OBS_VALUE_EUR':'0','CONTINUITY_TYPE':'complex_MN'},
        {'YEAR':'2012','HCN8_ID':'G_EXACT','ACTIVE_PRODUCTS':'61091000','ACTIVE_MEMBER_COUNT':'1','OBSERVED_MEMBER_COUNT':'1','OBS_VALUE_EUR':'0','CONTINUITY_TYPE':'1:1_exact'},
        {'YEAR':'2013','HCN8_ID':'G_EXACT','ACTIVE_PRODUCTS':'61091000','ACTIVE_MEMBER_COUNT':'1','OBSERVED_MEMBER_COUNT':'1','OBS_VALUE_EUR':'200','CONTINUITY_TYPE':'1:1_exact'},
    ])
    out=root/'out';s=run(inputs,out)
    assert s['observed_trade_rows']==3,s
    assert s['explicitly_observed_zeros']==1,s
    assert s['no_report_on_active_codes']==2,s
    assert s['inactive_codes']==1,s
    panel=list(csv.DictReader((out/'cn8_validity_trade_panel_MISSING_SAFE.csv').open()))
    miss=[r for r in panel if r['ANALYSIS_STATUS']=='ACTIVE_BUT_NO_REPORTED_TRADE']
    assert len(miss)==2 and all(r['STRICT_OBSERVED_VALUE_EUR']=='' for r in miss)
    zero=[r for r in panel if r['ANALYSIS_STATUS']=='OBSERVED_ZERO']
    assert len(zero)==1 and zero[0]['STRICT_OBSERVED_VALUE_EUR']=='0'
    gr=list(csv.DictReader((out/'hcn8_group_year_MISSING_SAFE_REVIEW.csv').open()))
    mixed2013=next(r for r in gr if r['YEAR']=='2013' and r['HCN8_ID']=='G_MIX')
    assert mixed2013['EVER_IN_HISTORY_HS2_MIX']=='1' and mixed2013['CURRENT_YEAR_HS2_MIX']=='0'
    assert mixed2013['FULL_GROUP_OBSERVED_VALUE_EUR_IF_COMPLETE']==''
    exact2012=next(r for r in gr if r['YEAR']=='2012' and r['HCN8_ID']=='G_EXACT')
    assert exact2012['PROVISIONAL_COMPLETE_EXACT_VALUE_EUR']=='0'
    print('PASS 9 synthetic zero/missing/group tests; NO official data validation performed')
