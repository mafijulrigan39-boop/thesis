#!/usr/bin/env python3
"""Audit the ACTUAL user-submitted DS-059322 CN8 file against the DS-045409
ANNUAL SUMMARY (not raw observations) and DG TRADE published PDF snapshots.
Does not claim official source authentication without independent raw downloads.
"""
import csv,json,hashlib,re,sys,collections,datetime,pathlib
from decimal import Decimal
ROOT=pathlib.Path(__file__).resolve().parent
INPUT=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path('/mnt/data/eu_imports_bangladesh_cn8_2012_2025.csv')
OTHER=pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else pathlib.Path('/mnt/data/independent_reconciliation.csv')
SRC_SUMS={2012:8190980243,2013:9115978459,2014:10421299379,2015:12715949830,2016:13779755619,2017:14251416207,2018:15201621962,2019:16291646246,2020:13532808957,2021:15735974326,2022:23990994617,2023:18944474058,2024:19925531672,2025:21244359364}
# Official DG Trade 'Trade with Bangladesh' factsheet, year-specific page snapshots
# 20 May 2026 p.3: 2015–2025, COMEXT statistical regime 4, million EUR.
DG2026={2015:12716,2016:13780,2017:14251,2018:15202,2019:16292,2020:13533,2021:15736,2022:23991,2023:18939,2024:19923,2025:21179}
# 8 May 2025 p.3, same PDF URL but older publication vintage, 2024 EUR 19,880m.
DG2025={2014:10421,2015:12716,2016:13780,2017:14251,2018:15202,2019:16292,2020:13533,2021:15736,2022:23980,2023:18937,2024:19880}
FACTSHEET='https://webgate.ec.europa.eu/isdb_results/factsheets/country/details_bangladesh_en.pdf'

def sha(p):
 with open(p,'rb') as f:
  h=hashlib.sha256()
  for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk)
  return h.hexdigest()
def write(name,header,rows):
 with open(ROOT/name,'w',encoding='utf-8',newline='') as f:
  w=csv.writer(f);w.writerow(header);w.writerows(rows)
A=collections.defaultdict(lambda:{'n':0,'sum':0,'zero':0})
keys=set();allcodes=set();meta=collections.defaultdict(collections.Counter);bad=[]
with open(INPUT,encoding='utf-8-sig',newline='') as f:
 reader=csv.DictReader(f)
 required={'DATASET','FREQ','REPORTER','PARTNER','PRODUCT','FLOW','STAT_PROCEDURE','INDICATORS','TIME_PERIOD','OBS_VALUE'}
 assert required.issubset(set(reader.fieldnames or [])),'Required source fields missing'
 for i,r in enumerate(reader,2):
  y=int(r['TIME_PERIOD']); p=r['PRODUCT']; v=int(r['OBS_VALUE']);
  if y<2012 or y>2025 or not re.fullmatch('[0-9]{8}',p) or v<0:bad.append([i,y,p,v])
  k=(y,p)
  if k in keys:bad.append(['duplicate',i,y,p])
  keys.add(k);allcodes.add(p);s=A[y];s['n']+=1;s['sum']+=v;s['zero']+=int(v==0)
  for k2 in ['DATASET','FREQ','REPORTER','PARTNER','FLOW','STAT_PROCEDURE','INDICATORS']:meta[k2][r[k2]]+=1
assert not bad,f'invalid rows {bad[:3]}'
assert sorted(A)==list(range(2012,2026))
B={}
with open(OTHER,encoding='utf-8-sig',newline='') as f:
 for r in csv.DictReader(f):B[int(r['YEAR'])]=r
assert sorted(B)==list(range(2012,2026))
ROWS=[];DGROWS=[]
for y in range(2012,2026):
 a=A[y];b=B[y];bst=int(b['CN8_SUM_EUR']);btotal=int(b['REPORTED_TOTAL_EUR']);base=SRC_SUMS[y]; delta=bst-a['sum']
 own_gap=a['sum']-base;other_gap=bst-btotal
 ROWS.append([y,a['n'],int(b['CN8_ROWS']),int(b['CN8_ROWS'])-a['n'],a['sum'],bst,delta,base,btotal,btotal-base,own_gap,other_gap,round(own_gap/base*100,7),round(other_gap/btotal*100,7),b['SOURCE_URL'],b['SOURCE_SHA256'],'raw DS-045409 absent: SHA unverified'])
 if y in DG2026:
  dg=DG2026[y];DGROWS.append([y,base,round(base/1e6,6),dg,round(base/1e6-dg,6),round((base/1e6-dg)/dg*100,6),'2026-05-20',FACTSHEET])
 if y in DG2025:
  dg=DG2025[y];DGROWS.append([y,base,round(base/1e6,6),dg,round(base/1e6-dg,6),round((base/1e6-dg)/dg*100,6),'2025-05-08',FACTSHEET])
write('year_by_year_dataset_comparison.csv', ['year','ds059322_cn8_count_actual','ds045409_cn8_count_reported','count_difference_reported_minus_actual','ds059322_cn8_sum_eur_actual','ds045409_cn8_sum_eur_reported','cn8_sum_delta_eur','ds059322_reported_total_eur','ds045409_reported_total_eur','total_delta_eur','ds059322_cn8_minus_total_eur','ds045409_cn8_minus_total_eur','ds059322_pct_gap','ds045409_pct_gap','ds045409_claimed_source_url','ds045409_claimed_sha256','sha_verification_status'],ROWS)
write('dg_trade_factsheet_vintage_comparison.csv',['reference_year','codex_reported_total_eur','codex_reported_total_million_eur','dg_trade_imports_million_eur','codex_minus_dg_million_eur','codex_minus_dg_percent','dg_trade_publication_date','dg_trade_url'],DGROWS)
assert sum(x[3] for x in ROWS)==66
assert sum(x[6] for x in ROWS)==1504488
assert sum(x[10] for x in ROWS)==-61039072
assert sum(x[7] for x in ROWS)==213342790939
assert sum(x[8]-x[7] for x in ROWS)==3
manifest={
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_files':[{'file':str(p),'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in (INPUT,OTHER)],
 'reported_dataset_DS059322':{'actual_rows':sum(s['n'] for s in A.values()),'distinct_codes':len(allcodes),'actual_value_eur':sum(s['sum'] for s in A.values()),'reported_total_eur':sum(SRC_SUMS.values()),'total_residual_eur':sum(s['sum'] for s in A.values())-sum(SRC_SUMS.values()),'zero_rows':sum(s['zero'] for s in A.values()),'actual_metadata_unique':{k:dict(v) for k,v in meta.items()},'raw_export_receipt':'NOT PROVIDED'},
 'reported_dataset_DS045409':{'summary_only':True,'reported_rows':sum(int(b['CN8_ROWS']) for b in B.values()),'reported_value_eur':sum(int(b['CN8_SUM_EUR']) for b in B.values()),'sum_row_difference':sum(x[3] for x in ROWS),'sum_value_difference_eur':sum(x[6] for x in ROWS),'raw_data':'MISSING','claimed_source_sha256_status':'UNVERIFIABLE_WITHOUT_RAW_FILE'},
 'dg_trade_snapshot_2026_05_20':{'2025_mio_eur':21179,'2025_codex_total_mio_eur':round(SRC_SUMS[2025]/1e6,6),'difference_mio_eur':round(SRC_SUMS[2025]/1e6-21179,6),'has_reporting_vintage_discrepancy':True},
 'authenticity_approval':False,
 'blockers':['No raw DS-045409 source responses to compare by CN8-year','No original DS-059322 Easy Comext export receipt/raw source','No same-vintage independent official Comext totals and product records to identify difference causes','No complete historical source snapshots or data release timestamps in uploaded CSV']
}
(ROOT/'authentication_audit_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest,indent=2))
