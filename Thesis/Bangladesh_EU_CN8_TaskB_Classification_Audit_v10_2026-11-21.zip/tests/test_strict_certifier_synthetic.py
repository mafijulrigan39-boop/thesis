from pathlib import Path
from tempfile import TemporaryDirectory
import csv,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from certify_cn8_concordance_strict import run

def write(p,head,rows):
 with open(p,'w',newline='') as f:
  w=csv.writer(f);w.writerow(head);w.writerows(rows)

with TemporaryDirectory() as tmp:
 root=Path(tmp);ins=root/'inputs';ins.mkdir();out=root/'out'
 for y in range(2012,2026):
  codes=[('00000001','stable product'),('00000002','product A')]
  if y>=2017:codes=[('00000001','stable product'),('00000003','product A part 1'),('00000004','product A part 2')]
  write(ins/f'CN_{y}_catalog.csv',['code','description','source_url'],[(code,desc,'https://official.example') for code,desc in codes])
 for y in range(2012,2025):
  rows=[]
  if y==2016: rows=[('00000002','00000003','split','https://official.example'),('00000002','00000004','split','https://official.example')]
  write(ins/f'CN_{y}_to_{y+1}_changes.csv',['from_code','to_code','relation','source_url'],rows)
 trade=[]
 for y in range(2012,2026):
  trade.append(['00000001',y,10+(y-2012)*5])
  if y<2017:trade.append(['00000002',y,100])
  else:
   trade.append(['00000003',y,40]);
   if y!=2020:trade.append(['00000004',y,60]) # deliberately absent in 2020, MUST NOT treat as zero
 t=root/'trade.csv';write(t,['PRODUCT','TIME_PERIOD','OBS_VALUE'],trade)
 s=run(str(t),str(ins),str(out),min_catalogue_size=1,synthetic=True)
 assert s['full_official_catalogues']==14 and s['full_official_change_tables']==13
 assert s['full_period_growth_families']==1,s
 assert s['unreported_family_years']>=1,s
 growth=list(csv.DictReader(open(out/'certified_full_period_growth.csv')))
 assert growth[0]['value_2012_eur']=='10' and growth[0]['value_2025_eur']=='75',growth
 assert s['status']=='SYNTHETIC_TEST_ONLY'
 print('SYNTHETIC STRICT HARMONIZATION TEST PASSED:',s)
