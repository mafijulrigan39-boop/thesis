# Bangladesh–EU thesis | Task B: CN8 classification harmonization | v10

**Status: classification-risk audit complete; official 2012–2025 product concordance NOT YET COMPLETE.**

This package does not include 14 official annual CN code lists or 13 official original year-to-year conversion files; they could not be downloaded from this execution environment. It contains real-data descriptive audits, a priority list of historical-change indicators from a **secondary** Eurostat-RAMON-derived source, official source discovery and a strict, fail-closed future harmonization engine.

## Best starting files

- `CN8_TaskB_Classification_Audit_v10.xlsx`: workbook summarising the actual data, changes/coverage and missing official sources.
- `docs/TASK_B_FINDINGS_AND_LIMITATIONS.md`: detailed evidence, source list, limits and verdict.
- `data/2025_top200_native_code_with_concordance_risk.csv`: 2025 ranking with documented non-certification of historical stability.
- `data/observed_code_history_UNVERIFIED_semantics.csv`: 4,953 distinct raw codes, observed year counts, no semantic stability assumed.
- `data/annual_native_code_presence_turnover_NOT_CLASSIFICATION_CHANGES.csv`: 2012–2025 observed continuity by row, NOT code changes.
- `data/official_27_source_files_register.csv`: acquisition checklist for the 27 source files.
- `data/strict_fail_closed_attempt/source_completeness.json`: actual zero-official-file input status.
- `code/certify_cn8_concordance_strict.py`: normalized, complete-source-only harmonizer.
- `official_input_templates/`: **empty HEADER TEMPLATES ONLY**, not official data.

## Reproduce native-year audit (real Bangladesh data)

```bash
python code/build_task_b_audit.py \
  --input /path/to/eu_imports_bangladesh_cn8_2012_2025.csv \
  --out ./data
```

## Complete official source acquisition

Download complete official annual CN8 catalogues for each year 2012–2025, with English descriptions and validity information; download original year-to-year correspondence lists for **each of 13 successive pairs**; preserve the original XLS/XLSX/RDF inputs separately and capture full SHA-256 hashes, exact official URL, retrieval date, language and source version. Do not just copy the published annual code lists from a Bangladesh-filtered trade CSV.

Normalize each downloaded annual list to `official_inputs/CN_YYYY_catalog.csv` with columns `code,description,source_url`. Normalize each complete official year-to-year correspondence mapping to `official_inputs/CN_YYYY_to_YYYY+1_changes.csv` with columns `from_code,to_code,relation,source_url`. Use supported `relation` values `change`, `split`, `merge`, `complex`, `unchanged_explicit`, or `1_to_1`. If the official change list is directional, check all links and include all relevant source-to-target pairs. Need **complete change coverage**, not isolated examples.

Add a `source_manifest.csv` in `official_inputs/` with `filename,sha256,source_url,independently_verified,source_scope`. `independently_verified` must be `YES` based on an actual source check; `source_scope` is `FULL_OFFICIAL_ANNUAL_CN8` for catalogues and `FULL_OFFICIAL_YEAR_TO_YEAR_CHANGES` for correspondence tables. Do not fill a hash without verifying the original source files. Normalized-file SHA hashes are checked by the engine, so record the normalized file's SHA and separately archive the original file hash in your provenance log. The manifest cannot independently prove provenance merely because a user marks it YES; the researcher must retain external supporting evidence.

## Strict execution

```bash
python code/certify_cn8_concordance_strict.py \
  --trade /path/to/eu_imports_bangladesh_cn8_2012_2025.csv \
  --official-inputs ./official_inputs \
  --out ./certified_output
```

This **currently refuses to run**, because the official inputs are absent. That is intentional. Its audit output is `data/strict_fail_closed_attempt/source_completeness.json`.

## Synthetic test — never present as thesis findings

```bash
python tests/test_strict_certifier_synthetic.py
```

Test rows simulate a family split and missing trade observation; outputs are only marked `SYNTHETIC_TEST_ONLY`. The test passed in this run.

## Source principles

- Use year-specific CN8 values for 2025 tariff matching, once 2025 validity/description is checked.
- Use family-level harmonized values for historical comparisons **only after official full lineage audit**.
- Do not assume identical codes imply stable product definitions, missing rows imply zero, or HS6 prefixes solve HS-revision concordance.

The original `DS-059322` 27,780-row CSV is already archived in the project's previous v7 dataset; it is deliberately not duplicated here.
