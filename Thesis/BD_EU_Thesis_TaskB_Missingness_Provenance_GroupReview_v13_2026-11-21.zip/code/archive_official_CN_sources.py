#!/usr/bin/env python3
"""Archive official annual CN/transition source files with receipts and checksums.

Requires CANONICAL_RAW_DOWNLOAD_URL populated for EACH of 27 requirements.
This script does not discover nor guess URLs. Fails closed on missing sources,
non-HTTPS URLs, unapproved origins, and HTML errors masquerading as raw data.
Review retrieved files' content and source definitions separately before making
an official-equivalence certification decision.
"""
import argparse,csv,hashlib,json,re,sys,time
from pathlib import Path
from datetime import datetime,timezone
from urllib.parse import urlparse
import requests
ALLOWED=('ec.europa.eu','op.europa.eu','data.europa.eu','eur-lex.europa.eu',
         'ec.europa.eu','webgate.ec.europa.eu','taxation-customs.ec.europa.eu')

def run(registry:Path,directory:Path):
    directory.mkdir(parents=True,exist_ok=True)
    with registry.open(encoding='utf-8-sig',newline='') as f: records=list(csv.DictReader(f))
    if len(records)!=27:raise ValueError('Expected 14 annual lists + 13 official correspondence inputs')
    if len({r['REQUIREMENT_ID'] for r in records})!=27:raise ValueError('Duplicate source requirements')
    absent=[r['REQUIREMENT_ID'] for r in records if not r.get('CANONICAL_RAW_DOWNLOAD_URL','').strip()]
    if absent:
        (directory/'MISSING_OFFICIAL_INPUTS.json').write_text(json.dumps({'status':'NOT_DOWNLOADED','source_requirements_unresolved':absent},indent=2),encoding='utf-8')
        raise ValueError(f'Canonical official raw download URLs missing: {len(absent)} of 27; nothing authenticated')
    receipts=[]
    for r in records:
        url=r['CANONICAL_RAW_DOWNLOAD_URL']
        parsed=urlparse(url)
        if parsed.scheme!='https' or parsed.hostname not in ALLOWED:
            raise ValueError(f'Not a preapproved official HTTPS host: {url}')
        result={'id':r['REQUIREMENT_ID'],'requested_url':url,'downloaded_at_utc':datetime.now(timezone.utc).isoformat(), 'status':'FAILED'}
        try:
            resp=requests.get(url,timeout=(20,90),allow_redirects=True,headers={'User-Agent':'MITB-Thesis-EU-CN-Official-Source-Audit/1.0'})
            result.update(http_status=resp.status_code,final_url=resp.url,content_type=resp.headers.get('Content-Type',''),etag=resp.headers.get('ETag',''),last_modified=resp.headers.get('Last-Modified',''))
            resp.raise_for_status()
            if urlparse(resp.url).hostname not in ALLOWED:
                raise ValueError(f'Redirected outside official whitelisted domains: {resp.url}')
            if not resp.content or resp.content[:300].lower().lstrip().startswith((b'<!doctype html',b'<html')):
                raise ValueError('Empty/HTML response is not a usable classification source')
            suffix=Path(urlparse(resp.url).path).suffix or '.source'
            file=directory/(r['REQUIREMENT_ID']+suffix)
            file.write_bytes(resp.content)
            result.update(status='DOWNLOADED_NOT_YET_CONTENT_VERIFIED',saved_file=str(file),bytes=len(resp.content),sha256=hashlib.sha256(resp.content).hexdigest())
        except Exception as e:
            result['error']=str(e)
        receipts.append(result)
        (directory/'DOWNLOAD_RECEIPTS.json').write_text(json.dumps(receipts,indent=2),encoding='utf-8')
        time.sleep(.2)
    print(json.dumps({'succeeded':sum(x['status'].startswith('DOWNLOADED') for x in receipts),'required':27, 'all_content_definitions_still_require_manual_verification':True}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--registry',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    x=p.parse_args();run(x.registry,x.out)
