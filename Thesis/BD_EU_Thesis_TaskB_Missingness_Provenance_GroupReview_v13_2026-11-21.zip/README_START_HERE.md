# Task B v13: preserve true missingness, source authentication, group review

This package is a **conservative correction/QA layer**, not a certified official CN8 harmonization. It does not modify the user GitHub repository or overwrite any original research data.

## Completed immediately on real data
- `data/DS059322_observed_vs_absent_CODE_VALIDITY_UNKNOWN.csv`: 69,342 code/year rows, retains 155 source-reported zeroes; the 41,562 unreported entries have blank value and explicitly unknown official code validity.
- `data/DS059322_missingness_grid_manifest.json`: input SHA and totals.
- `data/top200_2025_longitudinal_DECISION_REGISTER.csv`: 200 2025-ranked CN8 lines with conservative status.
- `data/top20_nonexact_MANUAL_REVIEW_QUEUE.csv`: 20 significant split/merge/complex CN8 lines for review.
- `data/official_classification_27_source_receipt_REGISTER.csv`: missing official classification inputs (14 annual lists + 13 transition tables), all marked NOT_ARCHIVED.
- `docs/TASK_B_MISSINGNESS_PROVENANCE_COMPLEX_GROUP_REVIEW_v13.md`: detailed scientific decisions and known blockers.

## Steps to perform on the six original generated GitHub CSVs

1. Download/copy six CSVs from this pinned commit into the *same local directory*:
   https://github.com/mafijulrigan39-boop/thesis/tree/541b38090afba8d7462fe6bcd43aff8bc5c73f3a/cn8_harmonization_2012_2025
2. Run:
```
python code/create_missing_safe_harmonization.py \
  --repo-dir /path/to/cn8_harmonization_2012_2025 \
  --out /path/to/corrected_results
```
3. The output includes `cn8_validity_trade_panel_MISSING_SAFE.csv`, `hcn8_group_year_MISSING_SAFE_REVIEW.csv`, `hcn8_2025_COMPLEX_GROUP_REVIEW_REGISTER.csv`, and `missingness_integrity_summary.json`.
4. Check exact reported figures (27,846 trade rows, 156 observed zeros, 105,740 valid but unreported, 20,624 inactive, €213,283,256,355 observed trade value). A mismatch is a blocker, not a reason to massage the numbers.
5. For the official source receipts, fill in **actual** 27 official raw URLs (not landing pages) in the source register. Run:
```
python code/archive_official_CN_sources.py \
  --registry data/official_classification_27_source_receipt_REGISTER.csv \
  --out /path/to/official_source_archive
```
   This currently fails intentionally because none of the 27 official input URLs has yet been collected. Downloading the files and recording a SHA are necessary but not sufficient: verify definitions and correspondence semantics.

Run synthetic tests:
```
python code/test_missing_safe_harmonization.py
```
**Never treat a code with no observed trade row as an observed zero.** The GitHub-derived label `VERIFIED_ZERO` must not be used for final causal or growth inference without official completeness and disclosure evidence.
