# Eurostat source authentication — v8

This is a **stage-one source-integrity audit**, not a full officially authenticated data release.

## Contents
- `AUTHENTICATION_FINDINGS_v8.md`: evidence and decision in plain English, numeric comparisons and source-vintage caveats.
- `EU_Bangladesh_Comext_source_authentication_v8.xlsx`: formula-driven overview, annual comparisons, DG Trade publication vintages and source register.
- `year_by_year_dataset_comparison.csv`: full 14-year numerical cross-check between the observed DS-059322 extract and only the CLAIMED DS-045409 annual summary.
- `dg_trade_factsheet_vintage_comparison.csv`: user reported totals vs DG Trade 8 May 2025 and 20 May 2026 public tables.
- `authentication_audit_manifest.json`: SHA-256 hashes and exact source-availability flags.
- `audit_offline_v8.py`: reproducible offline data audit.
- `verify_raw_eurostat_v8.py`: raw official-response download, preservation, hash check and full CN8/year differencing. The script refuses certification if the downloaded inputs are absent/inconsistent.
- `live_attempt/raw_retrieval_log.json`: real failed 2025 filtered Comext request from this environment.
- `source_inputs/`: original user-uploaded 27,780-row CSV and `DS-045409` 14-row summary; user inputs are NOT re-labelled as authenticated official files.

Run offline: `python audit_offline_v8.py source_inputs/eu_imports_bangladesh_cn8_2012_2025.csv source_inputs/independent_reconciliation.csv`

Run official re-download with internet available:

```bash
python -m pip install requests
python verify_raw_eurostat_v8.py --input source_inputs/eu_imports_bangladesh_cn8_2012_2025.csv --summary source_inputs/independent_reconciliation.csv --out recheck --fetch
```

If raw annual Comext responses are supplied without downloading, name them `ds045409_2012.csv`, ..., `ds045409_2025.csv` inside a folder and use `--raw-dir /path/to/that/folder --out recheck`. A nonzero exit is an incomplete or failed authentication (by design).

## Strict conclusion
The official source identifiers are validated, the user-uploaded CSV and arithmetic are validated, and the DG Trade factsheet divergence is quantified, but the original source-level authenticity **cannot be certified here** because the 27,846-row DS-045409 raw dataset and original DS-059322 export receipt are unavailable. The 2025 difference must remain unresolved until a contemporaneous official download can be compared.
